var fs = require('fs');

/*
 * GET home page.
 */

exports.index = function(req, res){
  res.render('index', { title: 'Express' });
};

exports.readfile = function(req, res) {
	fs.readFile( 'public/textfiles/' + req.body.file_name+'.txt', function (err, data) {
		if (err) {
			console.log(err);
			
			if(err.errno==34){
				res.end('No such file exist');
			}
		} else {
			res.end(data);
		}
	});
}

exports.createfile = function(req, res) {
	if (req.body.file_name !="" && req.body.file_data !="") {
		fs.writeFile( 'public/textfiles/' + req.body.file_name+'.txt', req.body.file_data, function (err) {
			if (err){
				console.log(err);
				res.end('File could not be saved');
			} else {
				res.end('File has been saved');
			}
		});
	} else {
		res.end('Please provide file name and or content');
	}
}



